# notion-stockwidget
*TradingView Market Data widget for Notion embed*

**Live demo at https://boring-bartik-a3d13c.netlify.app/**

If you want to re-use this repo, make a TradingView account and go to https://www.tradingview.com/widget/market-quotes/ and add the symbols you want. Go to `index.html` and replace the current json with the new embed code. Make sure that in the widget with an id of "dark" that you set the `colourTheme` property to "dark". To make easy changes later, just copy the JSON in the embed code and paste it into `data.json`. For hosting I reccomend Netlfiy for one click deploys. If you use this for your own Notion please fork/star the repo! Enjoy😊
